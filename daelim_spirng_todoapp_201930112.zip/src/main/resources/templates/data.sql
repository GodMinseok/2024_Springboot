INSERT INTO TASK (title, content, completed, created_at, updated_at) VALUES ('제목1', '내용 1', 'Yes', NOW(), NOW());
