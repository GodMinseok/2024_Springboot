package org.example.daelim_spirng_todoapp_201930112;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaelimSpirngTodoapp201930112Application {

    public static void main(String[] args) {
        SpringApplication.run(DaelimSpirngTodoapp201930112Application.class, args);
    }

}
