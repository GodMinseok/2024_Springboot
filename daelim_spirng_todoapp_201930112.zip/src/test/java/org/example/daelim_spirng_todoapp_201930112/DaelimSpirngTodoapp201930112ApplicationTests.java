package org.example.daelim_spirng_todoapp_201930112;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaelimSpirngTodoapp201930112ApplicationTests {

    @Test
    void contextLoads() {
    }

}
